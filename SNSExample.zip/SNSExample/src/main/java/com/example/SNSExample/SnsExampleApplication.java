package com.example.SNSExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SnsExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SnsExampleApplication.class, args);
	}

}
